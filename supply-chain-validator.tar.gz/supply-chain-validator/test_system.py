"""
System Integration Test
Tests all components of the Supply Chain Validator
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from graph_database import GraphDatabase
from populate_data import populate_supply_chain_data
from graph_rag_engine import GraphRAGEngine
from certification_validator import CertificationValidator

def test_database():
    """Test graph database functionality"""
    print("\n" + "="*60)
    print("TEST 1: Graph Database")
    print("="*60)
    
    db = GraphDatabase()
    populate_supply_chain_data(db)
    
    schema = db.get_schema()
    print(f"✓ Database initialized")
    print(f"  - Nodes: {schema['node_count']}")
    print(f"  - Relationships: {schema['relationship_count']}")
    print(f"  - Node types: {', '.join(schema['node_labels'])}")
    
    # Test queries
    suppliers = db.get_all_nodes('Supplier')
    print(f"✓ Found {len(suppliers)} suppliers")
    
    materials = db.get_all_nodes('Material')
    print(f"✓ Found {len(materials)} materials")
    
    return db

def test_graph_rag(db):
    """Test GraphRAG engine"""
    print("\n" + "="*60)
    print("TEST 2: GraphRAG Engine")
    print("="*60)
    
    engine = GraphRAGEngine(db)
    
    # Test query
    question = "Who supplies the leather?"
    print(f"\nQuery: {question}")
    result = engine.query(question)
    
    print(f"✓ Query executed successfully")
    print(f"  - Intent: {result['query_plan'].get('intent', 'N/A')}")
    print(f"  - Results found: {result['result_count']}")
    print(f"  - Answer length: {len(result['answer'])} characters")
    
    # Test tracing
    print(f"\n✓ Testing supply chain tracing...")
    trace = engine.trace_supply_chain("PROD001")
    print(f"  - Product: {trace['product']['name']}")
    print(f"  - Factory: {trace['factory']['name'] if trace['factory'] else 'None'}")
    print(f"  - Materials: {len(trace['materials'])}")
    print(f"  - Suppliers: {len(trace['suppliers'])}")
    
    return engine

def test_certification_validator(db):
    """Test certification validator"""
    print("\n" + "="*60)
    print("TEST 3: Certification Validator")
    print("="*60)
    
    validator = CertificationValidator(db)
    
    # Test validation
    result = validator.validate_certification(
        query="Test validation",
        certification_id="CERT001"
    )
    
    print(f"✓ Certification validated")
    print(f"  - Certification: {result['certification_name']}")
    print(f"  - Status: {result['validation_status']}")
    print(f"  - Confidence: {result['confidence_level']}")
    
    # Test multiple validations
    results = validator.validate_all_certifications_for_query(
        query="Test multiple",
        certification_ids=["CERT001", "CERT002", "CERT003"]
    )
    
    summary = validator.get_certification_summary(results)
    print(f"\n✓ Multiple certifications validated")
    print(f"  - Total: {summary['total_certifications']}")
    print(f"  - Auto-approved: {summary['auto_approved']}")
    print(f"  - Human-approved: {summary['human_approved']}")
    print(f"  - Rejected: {summary['rejected']}")
    
    return validator

def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("SUPPLY CHAIN VALIDATOR - SYSTEM TEST")
    print("="*60)
    
    try:
        # Test 1: Database
        db = test_database()
        
        # Test 2: GraphRAG
        engine = test_graph_rag(db)
        
        # Test 3: Certification Validator
        validator = test_certification_validator(db)
        
        # Summary
        print("\n" + "="*60)
        print("ALL TESTS PASSED ✓")
        print("="*60)
        print("\nSystem is ready for demonstration!")
        print("\nTo run the application:")
        print("  streamlit run app.py")
        
    except Exception as e:
        print(f"\n✗ TEST FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())
